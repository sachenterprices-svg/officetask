document.addEventListener('DOMContentLoaded', () => {
    // Input Fields
    const inputs = {
        // Sender Details
        bsnlCircle: document.getElementById('bsnlCircle'),
        bsnlOA: document.getElementById('bsnlOA'),
        senderName: document.getElementById('senderName'),
        senderDesignation: document.getElementById('senderDesignation'),
        senderMobile: document.getElementById('senderMobile'),

        // Technical
        category: document.getElementById('customerCategory'),
        ipExt: document.getElementById('ipExt'),
        analogExt: document.getElementById('analogExt'),
        vasExt: document.getElementById('vasExt'),
        sipPlan: document.getElementById('sipPlan'),
        channels: document.getElementById('channels'),
        freeDid: document.getElementById('freeDid'),
        extraDid: document.getElementById('extraDid')
    };

    // UI Elements
    const els = {
        currentDate: document.getElementById('currentDate'),
        tableBody: document.getElementById('tableBody'),
        grandTotal: document.getElementById('grandTotal'),
        categoryFeatures: document.getElementById('categoryFeatures'),

        // SIP details preview
        prevSipPlan: document.getElementById('prevSipPlan'),
        prevChannels: document.getElementById('prevChannels'),
        prevFreeDids: document.getElementById('prevFreeDids'),
        staticIpWarning: document.getElementById('staticIpWarning'),
        staticIpNotePreview: document.getElementById('staticIpNotePreview'),

        // Sender preview
        senderInfoBox: document.getElementById('senderInfoBox'),
        prevSenderName: document.getElementById('prevSenderName'),
        prevDesignation: document.getElementById('prevDesignation'),
        prevCircleOA: document.getElementById('prevCircleOA'),
        prevMobile: document.getElementById('prevMobile'),
        footerSignature: document.getElementById('footerSignature'),

        // Export
        exportBtn: document.getElementById('exportBtn'),
        exportStatus: document.getElementById('exportStatus'),
        proposalPreview: document.getElementById('proposalPreview')
    };

    // Initialize Date
    const dateOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    els.currentDate.textContent = new Date().toLocaleDateString('en-IN', dateOptions);

    // BSNL Circle and OA Data
    const bsnlData = {
        "Andaman and Nicobar": ["Port Blair"],
        "Andhra Pradesh": ["Anantapur", "Chittoor", "Cuddapah", "East Godavari", "Guntur", "Krishna", "Kurnool", "Nellore", "Prakasam", "Srikakulam", "Visakhapatnam", "Vizianagaram", "West Godavari"],
        "Assam": ["Bongaigaon", "Cachar", "Dibrugarh", "Jorhat", "Kamrup", "Karbi Anglong", "Lakhimpur", "Nagaon", "Nalbari", "Sibsagar", "Tezpur"],
        "Bihar": ["Ara", "Aurangabad", "Begusarai", "Bhagalpur", "Chapra", "Darbhanga", "Gaya", "Hajipur", "Katihar", "Khagaria", "Munger", "Motihari", "Muzaffarpur", "Patna", "Purnea", "Saharsa", "Samastipur", "Sasaram"],
        "Chhattisgarh": ["Bastar", "Bilaspur", "Durg", "Raigarh", "Raipur", "Surguja"],
        "Chennai Telephones": ["Chennai"],
        "Gujarat": ["Ahmedabad", "Amreli", "Bharuch", "Bhavnagar", "Bhuj", "Godhra", "Himmatnagar", "Jamnagar", "Junagadh", "Kheda", "Mehsana", "Nadiad", "Palanpur", "Rajkot", "Surat", "Surendranagar", "Vadodara", "Valsad"],
        "Haryana": ["Ambala", "Faridabad", "Gurgaon", "Hissar", "Karnal", "Kurukshetra", "Panipat", "Rohtak", "Sirsa", "Sonepat"],
        "Himachal Pradesh": ["Dharamshala", "Hamirpur", "Kullu", "Mandi", "Shimla", "Solan"],
        "Jammu and Kashmir": ["Anantnag", "Baramulla", "Jammu", "Kathua", "Leh", "Rajouri", "Srinagar", "Udhampur"],
        "Jharkhand": ["Bokaro", "Dhanbad", "Dumka", "Hazaribagh", "Jamshedpur", "Ranchi"],
        "Karnataka": ["Bangalore", "Belagavi", "Bellary", "Bidar", "Bijapur", "Chikmagalur", "Dakshina Kannada", "Davanagere", "Dharwad", "Gadag", "Gulbarga", "Hassan", "Karwar", "Kolar", "Koppal", "Mandya", "Mysore", "Raichur", "Shimoga", "Tumkur", "Udupi"],
        "Kerala": ["Alappuzha", "Ernakulam", "Idukki", "Kannur", "Kasaragod", "Kollam", "Kottayam", "Kozhikode", "Malappuram", "Palakkad", "Pathanamthitta", "Thiruvananthapuram", "Thrissur", "Wayanad"],
        "Kolkata Telephones": ["Kolkata"],
        "Madhya Pradesh": ["Balaghat", "Betul", "Bhind", "Bhopal", "Chhatarpur", "Chhindwara", "Damoh", "Dewas", "Dhar", "Guna", "Gwalior", "Hoshangabad", "Indore", "Jabalpur", "Khandwa", "Khargone", "Mandsaur", "Morena", "Narsinghpur", "Neemuch", "Panna", "Raisen", "Rajgarh", "Ratlam", "Rewa", "Sagar", "Satna", "Sehore", "Seoni", "Shahdol", "Shajapur", "Shivpuri", "Sidhi", "Tikamgarh", "Ujjain", "Umaria", "Vidisha"],
        "Maharashtra": ["Ahmednagar", "Akola", "Amravati", "Aurangabad", "Beed", "Bhandara", "Buldhana", "Chandrapur", "Dhule", "Gadchiroli", "Gondia", "Hingoli", "Jalgaon", "Jalna", "Kalyan", "Kolhapur", "Latur", "Nagpur", "Nanded", "Nandurbar", "Nashik", "Osmanabad", "Parbhani", "Pune", "Raigad", "Ratnagiri", "Sangli", "Satara", "Sindhudurg", "Solapur", "Thane", "Wardha", "Washim", "Yavatmal"],
        "North East-I": ["Meghalaya", "Mizoram", "Tripura"],
        "North East-II": ["Arunachal Pradesh", "Manipur", "Nagaland"],
        "Odisha": ["Balasore", "Berhampur", "Bhubaneswar", "Cuttack", "Dhenkanal", "Keonjhar", "Koraput", "Phulbani", "Rourkela", "Sambalpur", "Sundargarh"],
        "Punjab": ["Amritsar", "Bathinda", "Chandigarh", "Ferozepur", "Hoshiarpur", "Jalandhar", "Ludhiana", "Pathankot", "Patiala", "Rupnagar", "Sangrur"],
        "Rajasthan": ["Ajmer", "Alwar", "Banswara", "Barmer", "Bharatpur", "Bhilwara", "Bikaner", "Bundi", "Chittorgarh", "Churu", "Dausa", "Dholpur", "Dungarpur", "Hanumangarh", "Jaipur", "Jaisalmer", "Jalore", "Jhalawar", "Jhunjhunu", "Jodhpur", "Karauli", "Kota", "Nagaur", "Pali", "Pratapgarh", "Rajsamand", "Sawai Madhopur", "Sikar", "Sirohi", "Sri Ganganagar", "Tonk", "Udaipur"],
        "Tamil Nadu": ["Chennai", "Coimbatore", "Cuddalore", "Dharmapuri", "Dindigul", "Erode", "Kanchipuram", "Kanyakumari", "Karur", "Krishnagiri", "Madurai", "Nagapattinam", "Namakkal", "Nilgiris", "Perambalur", "Pudukkottai", "Ramanathapuram", "Salem", "Sivaganga", "Thanjavur", "Theni", "Thoothukudi", "Tiruchirappalli", "Tirunelveli", "Tirupathur", "Tiruvallur", "Tiruvannamalai", "Tiruvarur", "Vellore", "Viluppuram", "Virudhunagar"],
        "Telangana": ["Adilabad", "Hyderabad", "Karimnagar", "Khammam", "Mahabubnagar", "Medak", "Nalgonda", "Nizamabad", "Rangareddy", "Warangal"],
        "Uttar Pradesh (East)": ["Allahabad", "Azamgarh", "Bahraich", "Ballia", "Banda", "Barabanki", "Basti", "Deoria", "Faizabad", "Farrukhabad", "Fatehpur", "Ghazipur", "Gonda", "Gorakhpur", "Hardoi", "Jaunpur", "Kanpur", "Lakhimpur", "Lucknow", "Mau", "Mirzapur", "Orai", "Pratapgarh", "Raebareli", "Shahjahanpur", "Sitapur", "Sultanpur", "Unnao", "Varanasi"],
        "Uttar Pradesh (West)": ["Agra", "Aligarh", "Bareilly", "Bijnor", "Budaun", "Bulandshahr", "Etah", "Etawah", "Ghaziabad", "Hapur", "Mathura", "Meerut", "Moradabad", "Muzaffarnagar", "Noida", "Pilibhit", "Rampur", "Saharanpur"],
        "Uttarakhand": ["Almora", "Dehradun", "Haldwani", "Haridwar", "Nainital", "Pauri", "Srinagar (Garhwal)", "Tehri"],
        "West Bengal": ["Asansol", "Bankura", "Birbhum", "Burdwan", "Cooch Behar", "Darjeeling", "Hooghly", "Howrah", "Jalpaiguri", "Kalyani", "Kharagpur", "Krishnanagar", "Malda", "Midnapore", "Murshidabad", "Purulia", "Raiganj", "Suri"]
    };

    // Populate Circle Dropdown
    const sortedCircles = Object.keys(bsnlData).sort();
    sortedCircles.forEach(circle => {
        const option = document.createElement('option');
        option.value = circle;
        option.textContent = circle;
        inputs.bsnlCircle.appendChild(option);
    });

    // Handle Circle Change to populate OA
    inputs.bsnlCircle.addEventListener('change', (e) => {
        const selectedCircle = e.target.value;
        const oas = bsnlData[selectedCircle] || [];

        inputs.bsnlOA.innerHTML = '<option value="">Select OA...</option>';
        inputs.bsnlOA.disabled = oas.length === 0;

        if (oas.length > 0) {
            oas.sort().forEach(oa => {
                const option = document.createElement('option');
                option.value = oa;
                option.textContent = oa;
                inputs.bsnlOA.appendChild(option);
            });
        }
        updateProposal();
    });

    // Event listeners for other inputs
    Object.values(inputs).forEach(input => {
        if (input && input !== inputs.bsnlCircle && input !== inputs.channels && input !== inputs.ipExt && input !== inputs.analogExt && input !== inputs.freeDid && input !== inputs.extraDid) {
            input.addEventListener('input', updateProposal);
            input.addEventListener('change', updateProposal);
        }
    });

    // Handle interactive calculation for Channels, IP and Analog Ext
    [inputs.channels, inputs.ipExt, inputs.analogExt].forEach(input => {
        if (input) {
            input.addEventListener('input', calculateDids);
            input.addEventListener('change', calculateDids);
        }
    });

    // Handle manual overrides for DID inputs
    [inputs.freeDid, inputs.extraDid].forEach(input => {
        if (input) {
            input.addEventListener('input', updateProposal);
            input.addEventListener('change', updateProposal);
        }
    });

    function calculateDids(e) {
        if (e && e.target === inputs.channels && e.type === 'change') {
            let val = parseInt(e.target.value) || 0;
            if (val < 10) val = 10;
            else if (val % 5 !== 0) {
                val = Math.round(val / 5) * 5;
            }
            e.target.value = val;
        }

        const channels = parseInt(inputs.channels.value) || 0;
        const ipQty = parseInt(inputs.ipExt.value) || 0;
        const analogQty = parseInt(inputs.analogExt.value) || 0;

        // 1. Free DIDs = 2x Channels
        const freeDids = channels * 2;
        inputs.freeDid.value = freeDids;

        // 2. Extra DIDs = Total required (IP + Analog) - Free DIDs. Min 0.
        const totalReq = ipQty + analogQty;
        const extraDids = Math.max(0, totalReq - freeDids);
        inputs.extraDid.value = extraDids;

        updateProposal();
    }

    // PDF Export Logic (Robust approach)
    els.exportBtn.addEventListener('click', () => {
        // Provide UI feedback
        const originalText = els.exportBtn.innerHTML;
        els.exportBtn.innerHTML = 'Generating PDF... Please wait';
        els.exportBtn.style.opacity = '0.7';
        els.exportBtn.disabled = true;
        els.exportStatus.style.display = 'none';

        // Fix for PDF Cutoff: explicitly controlling the width of the element before export.
        const originalWidth = els.proposalPreview.style.width;
        const originalPadding = els.proposalPreview.style.padding;
        const originalMargin = els.proposalPreview.style.margin;

        // A4 Paper ratio roughly, forces the div to respond like a contained page
        els.proposalPreview.style.width = '794px'; // ~ 210mm at 96 DPI
        els.proposalPreview.style.padding = '40px';
        els.proposalPreview.style.margin = '0 auto';

        const opt = {
            margin: 10, // Top, Right, Bottom, Left margins in mm
            filename: `BSNL_Proposal_${inputs.bsnlCircle.value || 'Default'}.pdf`,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2, useCORS: true, logging: false },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
        };

        // Small delay to allow UI to update text before intensive process
        setTimeout(() => {
            html2pdf().set(opt).from(els.proposalPreview).save()
                .then(() => {
                    // Restore original styles
                    els.proposalPreview.style.width = originalWidth;
                    els.proposalPreview.style.padding = originalPadding;
                    els.proposalPreview.style.margin = originalMargin;

                    els.exportBtn.innerHTML = originalText;
                    els.exportBtn.style.opacity = '1';
                    els.exportBtn.disabled = false;
                    els.exportStatus.style.display = 'block';
                    setTimeout(() => els.exportStatus.style.display = 'none', 4000);
                })
                .catch(err => {
                    // Restore original styles
                    els.proposalPreview.style.width = originalWidth;
                    els.proposalPreview.style.padding = originalPadding;
                    els.proposalPreview.style.margin = originalMargin;

                    console.error("PDF Generation Error: ", err);
                    alert("There was an error generating the PDF. Please try again.");
                    els.exportBtn.innerHTML = originalText;
                    els.exportBtn.style.opacity = '1';
                    els.exportBtn.disabled = false;
                });
        }, 300);
    });

    // Pricing Logic
    function getIpVasRate(qty) {
        if (qty === 0) return 0;
        if (qty < 48) return 300;
        if (qty >= 48 && qty <= 96) return 225;
        return 180;
    }

    function getAnalogRate(qty) {
        if (qty === 0) return 0;
        if (qty < 48) return 100;
        if (qty >= 48 && qty <= 96) return 75;
        return 60;
    }

    // Getting category specific features
    function getCategoryFeatures(category) {
        let title = "Enterprise EPABX Features";
        let features = [];

        switch (category) {
            case "Hospital":
                title = "Healthcare & Hospital EPABX Features";
                features = [
                    "Integration with Nurse Call System",
                    "Emergency Code Broadcasting (Code Blue)",
                    "Patient Room Intercom Integration",
                    "Doctor's Priority Routing",
                    "Wake-up Call & Billing Integration",
                    "Automated Appointment Reminders"
                ];
                break;
            case "CallCenter":
                title = "Call Center & BPO Features";
                features = [
                    "Advanced Interactive Voice Response (IVR)",
                    "Predictive & Progressive Dialer",
                    "100% Call Recording with Setup",
                    "Barge-in, Whisper & Call Monitoring",
                    "Detailed Agent Productivity Analytics",
                    "Skill-based Routing"
                ];
                break;
            case "Hotel":
                title = "Hospitality & Hotel Features";
                features = [
                    "Property Management System (PMS) Integration",
                    "Automated Wake-up Calls",
                    "Room Status / Maid Status Updates",
                    "Guest Voicemail (Multi-language)",
                    "Integrated Billing for Room Calls",
                    "Mini-bar status updates via phone"
                ];
                break;
            case "Enterprise":
            default:
                title = "Corporate Enterprise EPABX Features";
                features = [
                    "Multi-level Interactive Voice Response (IVR)",
                    "Audio/Video Conferencing Bridge",
                    "CRM Integration (Salesforce, Zoho, etc.)",
                    "Mobility Client (Softphone for remote work)",
                    "Detailed Call Data Records (CDR)",
                    "Secure Voice Mail to Email"
                ];
                break;
        }

        let html = `<h3>${title}</h3><ul>`;
        features.forEach(f => {
            html += `<li>${f}</li>`;
        });
        html += `</ul>`;

        return html;
    }

    // Main update logic
    function updateProposal() {
        // Collect values
        const vals = {
            c_circle: inputs.bsnlCircle.value.trim(),
            c_oa: inputs.bsnlOA.value.trim(),
            c_name: inputs.senderName.value.trim(),
            c_desig: inputs.senderDesignation.value.trim(),
            c_mobile: inputs.senderMobile.value.trim(),

            category: inputs.category.value,
            ipQty: parseInt(inputs.ipExt.value) || 0,
            analogQty: parseInt(inputs.analogExt.value) || 0,
            vasQty: parseInt(inputs.vasExt.value) || 0,
            sipPlan: inputs.sipPlan.value,
            channels: parseInt(inputs.channels.value) || 0,
            freeDids: parseInt(inputs.freeDid.value) || 0,
            extraDids: parseInt(inputs.extraDid.value) || 0
        };

        // Update Sender Details Preview
        const hasSenderInfo = vals.c_circle || vals.c_oa || vals.c_name || vals.c_desig || vals.c_mobile;

        if (hasSenderInfo) {
            els.senderInfoBox.style.display = 'block';
            els.prevSenderName.textContent = vals.c_name ? vals.c_name : '________________';
            els.prevDesignation.textContent = vals.c_desig ? ` (${vals.c_desig})` : '';

            let circleText = '';
            if (vals.c_circle && vals.c_oa) circleText = `${vals.c_circle} Circle, ${vals.c_oa} OA`;
            else if (vals.c_circle) circleText = `${vals.c_circle} Circle`;
            else if (vals.c_oa) circleText = `${vals.c_oa} OA`;
            else circleText = '________________';

            els.prevCircleOA.textContent = circleText;
            els.prevMobile.textContent = vals.c_mobile ? vals.c_mobile : '________________';

            // Also update footer signature
            els.footerSignature.innerHTML = `${vals.c_name || 'Authorized Signatory'}<br>${vals.c_desig ? vals.c_desig + '<br>' : ''}BSNL ${circleText}`;
        } else {
            els.senderInfoBox.style.display = 'none';
            els.footerSignature.innerHTML = 'Authorized Signatory<br>BSNL';
        }

        // Static IP Warning
        const needsStaticIp = vals.sipPlan === 'Internet';
        els.staticIpWarning.style.display = needsStaticIp ? 'block' : 'none';
        els.staticIpNotePreview.style.display = needsStaticIp ? 'block' : 'none';

        // Set SIP Details Text
        els.prevSipPlan.textContent = `BSNL SIP Trunk - ${vals.sipPlan}`;
        els.prevChannels.textContent = vals.channels;
        els.prevFreeDids.textContent = vals.freeDids;

        // Update Category Features Header
        els.categoryFeatures.innerHTML = getCategoryFeatures(vals.category);

        // Rates & Totals
        const ipRate = getIpVasRate(vals.ipQty);
        const analogRate = getAnalogRate(vals.analogQty);
        const vasRate = getIpVasRate(vals.vasQty);
        const extraDidRate = 10;

        const ipTotal = vals.ipQty * ipRate;
        const analogTotal = vals.analogQty * analogRate;
        const vasTotal = vals.vasQty * vasRate;
        const extraDidTotal = vals.extraDids * extraDidRate;

        const grandTotal = ipTotal + analogTotal + vasTotal + extraDidTotal;

        // Populate Table
        let rows = '';

        if (vals.ipQty > 0) {
            rows += `<tr>
                <td>IP Extensions Configuration</td>
                <td style="text-align: center;">${vals.ipQty}</td>
                <td style="text-align: right;">₹ ${ipRate.toLocaleString()}</td>
                <td style="text-align: right;">₹ ${ipTotal.toLocaleString()}</td>
            </tr>`;
        }
        if (vals.analogQty > 0) {
            rows += `<tr>
                <td>Analog Extensions Configuration</td>
                <td style="text-align: center;">${vals.analogQty}</td>
                <td style="text-align: right;">₹ ${analogRate.toLocaleString()}</td>
                <td style="text-align: right;">₹ ${analogTotal.toLocaleString()}</td>
            </tr>`;
        }
        if (vals.vasQty > 0) {
            rows += `<tr>
                <td>Value Added Services (Dialer, IVR, etc.)</td>
                <td style="text-align: center;">${vals.vasQty}</td>
                <td style="text-align: right;">₹ ${vasRate.toLocaleString()}</td>
                <td style="text-align: right;">₹ ${vasTotal.toLocaleString()}</td>
            </tr>`;
        }
        if (vals.extraDids > 0) {
            rows += `<tr>
                <td>Additional Direct Inward Dialing (DID)</td>
                <td style="text-align: center;">${vals.extraDids}</td>
                <td style="text-align: right;">₹ ${extraDidRate.toLocaleString()}</td>
                <td style="text-align: right;">₹ ${extraDidTotal.toLocaleString()}</td>
            </tr>`;
        }

        if (rows === '') {
            rows = `<tr><td colspan="4" style="text-align:center; padding: 25px; color:#64748b;">Please enter extension values to generate commercial details.</td></tr>`;
        }

        els.tableBody.innerHTML = rows;
        els.grandTotal.textContent = `₹ ${grandTotal.toLocaleString()}`;
    }

    // Initialize with default values on load
    calculateDids(); // First calculate DIDs, then update proposal
});
