const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 8080;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Basic Health Check Endpoint
app.get('/api/health', (req, res) => {
    res.status(200).json({ status: 'OK', message: 'Server is running normally' });
});

// Mock API endpoints for Proposals (to be connected to Firestore later)
const proposals = []; // In-memory substitution for now

// 1. Get all proposals
app.get('/api/proposals', (req, res) => {
    res.status(200).json(proposals);
});

// 2. Create a new proposal
app.post('/api/proposals', (req, res) => {
    const newProposal = {
        id: Date.now().toString(),
        createdAt: new Date().toISOString(),
        ...req.body
    };
    proposals.push(newProposal);
    res.status(201).json({ message: 'Proposal saved successfully', id: newProposal.id });
});

// Catch-all route to serve the frontend for any other requests (useful if using client-side routing later)
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
    console.log(`Open http://localhost:${PORT} in your browser.`);
});
